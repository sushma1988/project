

export default function() {
  // simulates data coming from a database.
  return Promise.resolve(
    [
        {
          custid: 1,
          name: "Acme",
          amt: 120,
          transactionDate: "05-01-2019"
        },
        {
          custid: 1,
          name: "Acme",
          amt: 75,
          transactionDate: "05-21-2019"
        },
        {
          custid: 1,
          name: "Acme",
          amt: 94,
          transactionDate: "05-21-2019"
        },
        {
          custid: 1,
          name: "Acme",
          amt: 10,
          transactionDate: "06-01-2019"
        },
        {
          custid: 1,
          name: "Acme",
          amt: 75,
          transactionDate: "06-21-2019"
        },
        {
          custid: 1,
          name: "Acme",
          amt: 200,
          transactionDate: "07-01-2019"
        },
        {
          custid: 1,
          name: "Acme",
          amt: 1,
          transactionDate: "07-04-2019"
        },
        {
          custid: 1,
          name: "Acme",
          amt: 80,
          transactionDate: "07-03-2019"
        },
        {
          custid: 1,
          name: "Acme",
          amt: 224,
          transactionDate: "07-21-2019"
        },
        {
          custid: 2,
          name: "Century",
          amt: 125,
          transactionDate: "05-01-2019"
        },
        {
          custid: 2,
          name: "Century",
          amt: 75,
          transactionDate: "05-21-2019"
        },
        {
          custid: 2,
          name: "Century",
          amt: 10,
          transactionDate: "06-01-2019"
        },
        {
          custid: 2,
          name: "Century",
          amt: 75,
          transactionDate: "06-21-2019"
        },
        {
          custid: 2,
          name: "Century",
          amt: 200,
          transactionDate: "07-01-2019"
        },
        {
          custid: 2,
          name: "Century",
          amt: 224,
          transactionDate: "07-21-2019"
        },
        {
          custid: 3,
          name: "Sallys Startup",
          amt: 120,
          transactionDate: "06-21-2019"
        }
    ]
  );
};